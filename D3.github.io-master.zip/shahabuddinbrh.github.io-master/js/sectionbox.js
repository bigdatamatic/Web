var sectionX = container.append('section')
    .attr('id', 'sectionX')
    .append('div')
    .classed('blue box', true)
    .append('p')
    .text('Dynamic Blue Box ');

var sectionY = container.append('section')
    .attr('id', 'sectionY')
    .append('div')
    .classed('red box', true)
    .append('p')
    .text('Dynamic Red Box');